<?php
	/* 
	------------------
	Language: Persian
	------------------
	*/
	$lang['english'] = "English";
	$lang['persian'] = "فارسی";
	$lang['onstorage'] = "OnStorage";
	
	/// Common
	$lang['delete'] = "حذف";
	$lang['add'] =  "افزودن";
	$lang['yes'] =  "بله";
	$lang['no'] =  "خیر";
	$lang['cancel'] =  "انصراف";
	$lang['edit'] =  "ویرایش";
	$lang['save'] =  "ذخیره";
	$lang['close'] = "بستن";
	
	/// Login
	$lang['login_title'] = "ورود به پنل مدیریت";
	$lang['email'] = "ایمیل";
	$lang['email_or_username'] = "ایمیل یا شناسه کاربری";
	$lang['password'] = "رمز ورود";
	$lang['login'] = "ورود";
	$lang['lost_password'] = "رمز عبور را فراموش کرده اید؟";
	$lang['login_failed'] = "ایمیل یا رمز ورود صحیح نیست";
	
	/// Lost Password
	$lang['forget_title'] = "دریافت رمز ورود جدید";
	$lang['get_password'] = "دریافت رمز ورود";
	$lang['forget_error'] =  "<strong>متاسفیم!</strong> این ایمیل یافت نشد.";
	$lang['forget_success'] =  "ایمیل برای %s ارسال شد.<br>لطفا بر روی لینکی که در ایمیل قرار دارد کلیک کنید تا بتوانید رمز جدید را تعیین کنید. ";
	$lang['reset_email_subject'] =  "بازیابی رمز ورود - OnStorage";
	$lang['reset_email_message'] =  "سلام %s!
شما درخواستی برای بازیابی رمز ورود خود کرده اید. اگر شما این کار را نکرده اید این پیام را نادیده بگیرید، درغیر این صورت بر روی لینک زیر کلیک کنید:
<a href='%s'>بازیابی رمز ورود</a>
با تشکر :)";
	
	/// Reset Password
	$lang['reset_title'] = "بازیابی رمز ورود";
	$lang['hello'] =  "سلام";
	$lang['new_password'] =  "رمز جدید";
	$lang['confirm_password'] =  "تکرار رمز جدید";
	$lang['change_password'] =  "تغییر رمز";
	$lang['reset_info'] =  "شما می توانید رمز عبور خود را از فرم زیر تغییر دهید.";
	$lang['reset_error'] =  "حساب کاربری یافت نشد. مجددا تلاش کنید";
	$lang['password_changed'] =  "رمز تغییر یافت";
	$lang['passwords_not_match'] =  "رمز جدید با تکرار آن مطابقت ندارد";
	
	/// Footer
	$lang['footer_text'] =  'طراحی توسط <a href="http://miladesign.ir">میلادیزاین</a>';
	
	/// Header
	$lang['dashboard'] = "پیشخوان";
	$lang['settings'] = 'تنظیمات';
	$lang['logout'] = 'خروج';
	$lang['home'] = 'صفحه اصلی';
	$lang['games'] = 'بازی ها';
	
	/// Admin
	$lang['shortcodes'] = "دسترسی سریع";
	$lang['docs'] = "مستندات";
	$lang['support_site'] = "سایت پشتیبانی";
	$lang['version_ok'] =  "شما از نسخه %s استفاده می کنید.";
	$lang['new_version'] =  "نسخه %s در دسترس است!";
	
	/// Settings
	$lang['change_details'] =  "تغییر مشخصات";
	$lang['current_password'] =  "رمز فعلی";
	$lang['current_password_error'] =  "رمز فعلی اشتباه است";
	$lang['details_changed'] =  "مشخصات تغییر یافت";
	
	/// Games
	$lang['id'] = "شناسه";
	$lang['name'] = "نام";
	$lang['token'] = "توکن";
	$lang['no_game'] =  "هیچ بازی وجود ندارد. <a href='#addgame'>افزودن بازی</a>";
	$lang['manage_values'] =  "مدیریت داده ها";
	$lang['manage_values_title'] =  "مدیریت داده های %s";
	$lang['manage_variables'] =  "مدیریت متغیرها";
	$lang['manage_variables_title'] =  "مدیریت متغیرهای %s";
	$lang['variable_key'] =  "نام متغیر";
	$lang['variable_type'] =  "نوع متغیر";
	$lang['variable_default'] =  "مقدار پیش فرض";
	$lang['add_variable'] =  "افزودن متغیر";
	$lang['add_variable_success'] =  "متغیر با موفقیت اضافه شد.";
	$lang['edit_variable_success'] =  "متغیر با موفقیت ویرایش شد.";
	$lang['delete_variable_success'] =  "متغیر با موفقیت حذف شد.";
	$lang['delete_variable_question'] =  "آیا از حذف این متغیر اطمینان دارید؟";
	$lang['duplicate_variable_error'] =  "متغیری با این نام وجود دارد.";
	$lang['delete_game_question'] =  "آیا از حذف این بازی اطمینان دارید؟";
	$lang['game_deleted_success'] =  "بازی با موفقیت حذف شد.";
	$lang['game_deleted_failed'] =  "خطایی در حذف بازی رخ داده است.";
	$lang['game_edit_success'] =  "بازی با موفقیت ویرایش شد.";
	$lang['game_edit_failed'] =  "خطایی در ویرایش بازی رخ داده است.";
	$lang['no_variable'] =  "این بازی هنوز متغیری ندارد. از فرم زیر یک متغیر جدید بسازید.";
	$lang['no_value'] =  "داده ای وجود ندارد.";
	$lang['add_game'] =  "افزودن بازی";
	$lang['database_error'] =  "خطا در دیتابیس";
	$lang['fill_all_data'] =  "لطفا همه اطلاعات را پر کنید";
	$lang['game_created'] =  "بازی ساخته شد";
	$lang['add_value'] =  "افزودن داده";
	$lang['user_id'] =  "شناسه کاربر";
	$lang['add_value_success'] =  "داده با موفقیت اضافه شد.";
	$lang['delete_value_success'] =  "داده با موفقیت حذف شد.";
	$lang['delete_value_failed'] =  "خطایی در حذف این داده رخ داده است.";
	$lang['delete_value_question'] =  "آیا از حذف این داده اطمینان دارید؟";
	$lang['duplicate_value_error'] =  "داده ای با این شناسه کاربری وجود دارد.";
	$lang['click_for_edit'] =  "برای ویرایش کلیک کنید";
	
	/// Install
	$lang['install'] = 'نصب';
	$lang['site_details'] = 'مشخصات سایت';
	$lang['sitename'] = 'نام سایت';
	$lang['database'] = 'دیتابیس';
	$lang['db_host'] = 'هاست';
	$lang['db_username'] = 'نام کاربری دیتابیس';
	$lang['db_password'] = 'رمز دیتابیس';
	$lang['db_name'] = 'نام دیتابیس';
	$lang['admin_user'] = 'مشخصات مدیر';
	$lang['admin_username'] = 'نام کاربری مدیر';
	$lang['admin_email'] = 'ایمیل مدیر';
	$lang['admin_password'] = 'رمز ورود مدیر';
	$lang['install_success'] = 'نصب با موفقیت انجام شد';
	$lang['sitename_desp'] = 'نام سایتی که در بالای تمامی صفحات نمایش داده می شود.';
	$lang['dbhost_desp'] = 'اگر localhost کار نکرد، باید این اطلاعات را از سرویس میزبانی خود بگیرید.';
	$lang['dbname_desp'] = 'نام پایگاه داده‌ای که می‌خواهید برای وردپرس استفاده کنید.';
	$lang['dbuser_desp'] = 'نام‌کاربری پایگاه‌داده‌ی شما.';
	$lang['dbpass_desp'] = 'رمز پایگاه‌داده شما.';
	$lang['adminemail_desp'] = 'نشانی ایمیل را پیش از ادامه دادن دوباره بررسی کنید.';
	$lang['adminpass_desp'] = 'مهم: به این رمز برای ورود نیاز خواهید داشت. لطفاً آن را در مکان امنی نگهداری کنید.';
	
	/// Demo
	$lang['demo_password'] = 'امکان تغییر رمز در حالت دمو وجود ندارد.';
	$lang['demo_details'] = 'امکان تغییر مشخصات در حالت دمو وجود ندارد.';
	
	/// Update
	$lang['update'] = 'بروزرسانی';
	$lang['update_to'] = 'بروزرسانی به نسخه %s';
	$lang['update_success'] = 'سیستم با موفقیت به نسخه %s ارتقا یافت.';
	$lang['update_error'] = 'خطایی در ارتقاء سیستم رخ داده است. مجددا تلاش کنید.';
	
	/// POST/GET
	$lang['missing_parameter'] = 'اطلاعات ارسالی ناقص هستند.';
?>