<?php
	/* 
	------------------
	Language: English
	------------------
	*/
	$lang['english'] = "English";
	$lang['persian'] = "فارسی";
	$lang['onstorage'] = "OnStorage";
	
	/// Common
	$lang['delete'] = "Delete";
	$lang['add'] =  "Add";
	$lang['yes'] =  "yes";
	$lang['no'] =  "No";
	$lang['cancel'] =  "Cancel";
	$lang['edit'] =  "Edit";
	$lang['save'] =  "Save";
	$lang['close'] = "Close";
	
	/// Login
	$lang['login_title'] = "Login to admin panel";
	$lang['email'] = "Email";
	$lang['email_or_username'] = "Email or UserName";
	$lang['password'] = "Password";
	$lang['login'] = "Login";
	$lang['lost_password'] = "Forget your password?";
	$lang['login_failed'] =  "Email or password incorrect";
	
	/// Lost Password
	$lang['forget_title'] = "Get new password";
	$lang['get_password'] = "Get password";
	$lang['forget_error'] =  "<strong>Sorry!</strong>  this email not found.";
	$lang['forget_success'] =  "We've sent an email to %s.<br>Please click on the password reset link in the email to generate new password. ";
	$lang['reset_email_subject'] =  "Reset Password - OnStorage";
	$lang['reset_email_message'] =  "Hello %s!
We got requested to reset your password, if you do this then just click the following link to reset your password, if not just ignore this email,
<a href='%s'>Click here to reset your password</a>
Thank you :)";
	
	/// Reset Password
	$lang['reset_title'] = "Reset password";
	$lang['hello'] =  "Hello";
	$lang['new_password'] =  "New Password";
	$lang['confirm_password'] =  "Confirm Password";
	$lang['change_password'] =  "Change Password";
	$lang['reset_info'] =  "You are here to reset your forgetton password.";
	$lang['reset_error'] =  "No Account Found, Try again";
	$lang['password_changed'] =  "Password changed";
	$lang['passwords_not_match'] =  "New Password and confirm password not matchs";
	
	/// Footer
	$lang['footer_text'] =  'Designed by <a href="http://miladesign.ir">MilaDesign</a>';
	
	/// Header
	$lang['dashboard'] = "Dashboard";
	$lang['settings'] = 'Settings';
	$lang['logout'] = 'Logout';
	$lang['home'] = 'Home';
	$lang['games'] = 'Games';
	
	/// Admin
	$lang['shortcodes'] = "Shortcodes";
	$lang['docs'] = "Documentation";
	$lang['support_site'] = "Support Site";
	$lang['version_ok'] =  "You are using %s version.";
	$lang['new_version'] =  "Version %s available now!";
	
	/// Settings
	$lang['change_details'] =  "Change Details";
	$lang['current_password'] =  "Current Password";
	$lang['current_password_error'] =  "Current password is wrong";
	$lang['details_changed'] =  "Details changed";
	
	/// Games
	$lang['id'] = "Id";
	$lang['name'] = "Name";
	$lang['token'] = "Token";
	$lang['no_game'] =  "No game exists. <a href='#addgame'>Add Game</a>";
	$lang['manage_values'] =  "Manage Values";
	$lang['manage_values_title'] =  "Manage %s Values";
	$lang['manage_variables'] =  "Manage Variables";
	$lang['manage_variables_title'] =  "Manage %s Variables";
	$lang['variable_key'] =  "Variable Key";
	$lang['variable_type'] =  "Variable Type";
	$lang['variable_default'] =  "Default Value";
	$lang['add_variable'] =  "Add Variable";
	$lang['add_variable_success'] =  "The variable has been added successfully.";
	$lang['edit_variable_success'] =  "The variable has been successfully edited.";
	$lang['delete_variable_success'] =  "The variable has been successfully deleted.";
	$lang['delete_variable_question'] =  "Are you sure you want to remove this variable?";
	$lang['duplicate_variable_error'] =  "There is a variable with this name.";
	$lang['delete_game_question'] =  "Are you sure you want to remove this game?";
	$lang['game_deleted_success'] =  "The game was successfully removed.";
	$lang['game_deleted_failed'] =  "There was an error deleting the game.";
	$lang['game_edit_success'] =  "The game was successfully edited.";
	$lang['game_edit_failed'] =  "There was an error editing the game.";
	$lang['no_variable'] =  "This game is still not has variable. Create a new variable from the form below.";
	$lang['no_value'] =  "There is no value.";
	$lang['add_game'] =  "Add Game";
	$lang['database_error'] =  "Database error";
	$lang['fill_all_data'] =  "Please fill all data";
	$lang['game_created'] =  "Game Added.";
	$lang['add_value'] =  "Add Value";
	$lang['user_id'] =  "User Id";
	$lang['add_value_success'] =  "Value added successfully.";
	$lang['delete_value_success'] =  "Value deleted successfully.";
	$lang['delete_value_failed'] =  "There was an error deleting this value.";
	$lang['delete_value_question'] =  "Are you sure you want to delete this value?";
	$lang['duplicate_value_error'] =  "There is some value with this user id.";
	$lang['click_for_edit'] =  "Click to edit";
	
	/// Install
	$lang['install'] = 'Install';
	$lang['site_details'] = 'Site Details';
	$lang['sitename'] = 'Site Name';
	$lang['database'] = 'Database';
	$lang['db_host'] = 'Host Name';
	$lang['db_username'] = 'Database Username';
	$lang['db_password'] = 'Database Password';
	$lang['db_name'] = 'Database Name';
	$lang['admin_user'] = 'Admin Informations';
	$lang['admin_username'] = 'Admin Username';
	$lang['admin_email'] = 'Admin Email';
	$lang['admin_password'] = 'Admin Password';
	$lang['install_success'] = 'Install Success!';
	$lang['sitename_desp'] = 'Site name that displayed in all pages title.';
	$lang['dbhost_desp'] = 'You should be able to get this info from your web host, if localhost doesn’t work.';
	$lang['dbname_desp'] = 'The name of the database you want to use with WordPress.';
	$lang['dbuser_desp'] = 'Your database username.';
	$lang['dbpass_desp'] = 'Your database password.';
	$lang['adminemail_desp'] = 'Double-check your email address before continuing.';
	$lang['adminpass_desp'] = 'Important: You will need this password to log in. Please store it in a secure location.';
	
	/// Demo
	$lang['demo_password'] = 'You cant change password in demo mode.';
	$lang['demo_details'] = 'You cant change details in demo mode.';
	
	/// Update
	$lang['update'] = 'Update';
	$lang['update_to'] = 'Update to %s version';
	$lang['update_success'] = 'System successfully updated to version %s.';
	$lang['update_error'] = 'An error occurred while updating the system. Try again.';
	
	/// POST/GET
	$lang['missing_parameter'] = 'All submissions are incomplete.';
?>