<?php
require_once 'include/class.user.php';
$user_home = new USER();
if (!empty($_GET["action"])) {
    $action = $_GET["action"];
    switch ($action) {
        case 'editGame':
            if (!empty($_GET["id"])) {
                $id = $_GET["id"];
            }
            if (!empty($_GET["name"])) {
                $name = $_GET["name"];
            }
            if (empty($id) || empty($name)) {
                echo 0;
                return;
            } else {
                $sql = "UPDATE games SET name='$name' WHERE id=?";
                $stmt = $user_home->prepareQuery($sql);
                $stmt->bind_param('i', $id);
                if ($stmt->execute()) {
                    echo 1;
                } else {
                    echo 0;
                }
            }
        break;
        case 'deleteGame':
            if (!empty($_GET["id"])) {
                $id = $_GET["id"];
            }
            if (!empty($_GET["token"])) {
                $token = $_GET["token"];
            }
            if (empty($id) || empty($token)) {
                echo 0;
                return;
            } else {
                $query = "DELETE FROM games WHERE id=$id;";
                $query.= "DROP TABLE IF EXISTS {$token}_variables;";
                if ($user_home->multiQuery($query)) {
                    echo 1;
                } else {
                    echo 0;
                }
            }
        break;
        case 'deleteValue':
            if (!empty($_GET["id"])) {
                $userId = $_GET["id"];
            }
            if (!empty($_GET["token"])) {
                $token = $_GET["token"];
            }
            if (empty($userId) || empty($token)) {
                echo 0;
                return;
            } else {
                if ($stmt = $user_home->runQuery("DELETE FROM {$token}_variables WHERE user_id='$userId'")) {
                    echo 1;
                } else {
                    echo 0;
                }
            }
        break;
    }
}
function record_exists($table, $column1, $value1, $column2, $value2) {
    $user_home = new USER();
    $stmt = $user_home->prepareQuery("SELECT * FROM $table WHERE $column1=? AND $column2=?");
    $stmt->bind_param('si', $value1, $value2);
    $stmt->execute();
    $stmt->store_result();
    $stmt->fetch();
    if ($stmt->num_rows > 0) {
        return true;
    } else {
        return false;
    }
}
?>