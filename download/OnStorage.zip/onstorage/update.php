﻿<?php
	include_once('header.php');
	if(!$user_home->is_logged_in()) {
		$user_home->redirect('login.php');
	}
	$json = file_get_contents("http://bayanbox.ir/view/6524786832242629325/onstorage.txt");
	$obj = json_decode($json);
	$latest = $obj->version;
	$message = "";
	$alert = "";
	if (!empty($_POST['action'])) {
		if ($stmt = $user_home->runQuery("UPDATE users SET version='$latest' WHERE id=1")) {
			unlink("update.php");
			$user_home->redirect('index.php?update=OK');
		} else {
			$message = $lang['database_error'];
			$alert = "alert alert-danger";
		}
	}
?>
	<?php if (!empty($message)) { ?>
		<div id="message">
			<div class="<?= $alert; ?>" id="alert">
				<?= $message; ?>
			</div>
		</div>
	<?php } ?>
		<div class="row">
			<div class="col-12">
				<div class="widget">
					<div class="widget-header"> <i class="icon-edit"></i>
						<h3> <?= $lang['update']; ?></h3>
					</div>
					<div class="widget-content">
						<form action="" method="POST">
							<input type="hidden" id="action" name="action" value="update" />
							<button type="submit" class="btn btn-primary"><?= sprintf($lang['update_to'], $latest); ?></button>
						</form>
					</div>
				</div>
			</div>
	  </div>
<?php include_once ('footer.php'); ?>