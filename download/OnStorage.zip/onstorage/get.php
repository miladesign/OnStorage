<?php
	header('Access-Control-Allow-Origin: *');
	header('Content-type: application/json');
	require_once 'include/class.user.php';
	$user_home = new USER();

	if (!empty($_GET["action"])) {
		$action = $_GET["action"];
		switch ($action) {
			case 'values':
				if (!empty($_GET["userId"])) {
					$userId = $_GET["userId"];
				}
				if (!empty($_GET["token"])) {
					$token = $_GET["token"];
				}
				if (!empty($_GET["lang"])) {
					$language = $_GET["lang"];
				}
				
				if (empty($userId) || empty($token) || empty($language)) {
                    $return["status"] = "error";
					$return["data"] = "Missing Parameter";
					echo json_encode($return);
					return;
				} else {
					$fields = array();
					$types = array();
					
					if ($stmt = $user_home->runQuery("SHOW COLUMNS FROM " . $token . "_variables")) {
						$i = 0;
						while ($row = $stmt->fetch_array(MYSQLI_ASSOC)) {
							if ($row['Field'] != 'game_id') {
								$fields[$i] = $row['Field'];
								$types[$i] = $row['Type'];
								$i++;
							}
						}
					}
					
					$values = array();
					
					if ($stmt = $user_home->runQuery("SELECT * FROM " . $token . "_variables WHERE user_id='$userId'")) {
						while ($row = $stmt->fetch_array(MYSQLI_ASSOC)) {
							$v_values = array_values($row);
							array_shift($v_values);
							$values = $v_values;
						}
					}
					$data = json_encode(array("fields" => $fields, "types" => $types, "values" => $values));
					echo json_encode(array(
						"status" => "success",
						"data" => $data
					));
				}
				break;
		}
	}
	
	function record_exists ($table, $column1, $value1, $column2, $value2) {
		$user_home = new USER();
		$stmt = $user_home->prepareQuery("SELECT * FROM $table WHERE $column1=? AND $column2=?");
		$stmt->bind_param('si', $value1, $value2);
		$stmt->execute();
		$stmt->store_result();
		$stmt->fetch();
		if ($stmt->num_rows > 0) {
			return true;
		} else {
			return false;
		}
	}
?>