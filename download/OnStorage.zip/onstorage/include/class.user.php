<?php

require_once 'dbconfig.php';

class USER {	

	private $conn;
	
	public function __construct() {
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function prepareQuery($sql) {
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function runQuery($sql) {
		$stmt = $this->conn->query($sql);
		return $stmt;
	}
	
	public function multiQuery($sql) {
		$stmt = $this->conn->multi_query($sql);
		return $stmt;
	}
	
	public function lasdID() {
		$stmt = $this->conn->insert_id;
		return $stmt;
	}
	
	public function register($uname, $email, $upass, $siteurl, $sitename, \mysqli $database) {
		try {							
			$password = md5($upass);
			$stmt = $database->prepare("INSERT INTO users(id, username, email, password, url, sitename, version)  VALUES(1, ?, ?, ?, ?, ?, '1.0')");
            $stmt->bind_param('sssss', $uname, $email, $password, $siteurl, $sitename);
			$stmt->execute();	
			return $stmt;
		} catch(Exception $ex) {
			echo $ex->getMessage();
		}
	}
	
	public function login($login,$upass) {
		try {
			$stmt = $this->conn->prepare("SELECT id, password FROM users WHERE ( username='$login' OR email = '$login')");
            $stmt->execute();
            $stmt->store_result();

            // Get variables from result
            $stmt->bind_result($userId, $password);
            $stmt->fetch();
			
			if($stmt->num_rows == 1) {
				if($password==md5($upass)) {
					$_SESSION['userId'] = $userId;
					$_SESSION['login'] = $login;
					return true;
				} else {
					header("Location: login.php?error");
					exit;
				}
			} else {
				header("Location: login.php?error");
				exit;
			}		
		} catch(Exception $ex) {
			echo $ex->getMessage();
		}
	}
	
	
	public function is_logged_in() {
		if(isset($_SESSION['userId'])) {
			return true;
		}
	}
	
	public function redirect($url) {
		header("Location: $url");
	}
	
	public function logout() {
		//session_destroy();
		unset($_SESSION['userId']);
		unset($_SESSION['login']);
	}
	
	function send_mail($email,$text,$subject) {
		$message = nl2br($text);
		$headers = 'From: rezagah.milad@gmail.com' . "\r\n" . 'Reply-To: rezagah.milad@gmail.com' . "\r\n" . 'X-Mailer: PHP/' . phpversion();
		$result	= @mail($email, $subject, $message, $headers);
	}	
}