<?php

require_once 'dbconfig.php';

class DB {	

	private $conn;
	
	public function __construct() {
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function prepareQuery($sql) {
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function runQuery($sql) {
		$stmt = $this->conn->query($sql);
		return $stmt;
	}
	
	public function multiQuery($sql) {
		$stmt = $this->conn->multi_query($sql);
		return $stmt;
	}
	
	public function lasdID() {
		$stmt = $this->conn->insert_id;
		return $stmt;
	}
}