<?php
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	
	class Database {
		private $host = "__DBHOSTNAME__";
		private $db_name = "__DBDATABASE__";
		private $username = "__DBUSERNAME__";
		private $password = "__DBPASSWORD__";
		public $conn;

		
		public function dbConnection() {
			$this->conn = null;    
			try {
				$this->conn = new \mysqli($this->host, $this->username, $this->password, $this->db_name);
				$this->conn->set_charset("utf8");
			} catch(Exception $exception) {
				echo "Connection error: " . $exception->errorMessage();
			}
			return $this->conn;
		}
	}
?>